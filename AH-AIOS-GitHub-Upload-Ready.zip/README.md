# AH-AIOS — GitHub Pages Website

A responsive, static website for **AH-AIOS**, the proposed civilization intelligence platform, including WorldForge, Hermes, governance architecture, and the AFTER HUMANITY story universe.

## Included

- `index.html` — full landing page and content
- `styles.css` — responsive dark sci-fi design, mobile navigation, accessibility and reduced-motion support
- `script.js` — mobile menu, searchable page sections, interactive AFTER HUMANITY chapter selector, dynamic year, and copy-summary action
- `assets/worldforge-city-hero.jpg` — hero image derived from the generated visual concept
- `assets/after-humanity-story.jpg` — story feature image
- `assets/favicon.svg` — site icon
- `.github/workflows/pages.yml` — GitHub Pages deployment workflow

## Preview locally

Open `index.html` in a browser, or run a local static server from this folder:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Deploy to GitHub Pages

1. Create a GitHub repository, for example `ah-aios-website`.
2. Upload the contents of this package to the **repository root** (so `index.html` and `.github/` are at the root).
3. Push the files to the default branch, usually `main`.
4. In the repository, open **Settings → Pages** and set the publishing source to **GitHub Actions** if it is not already selected.
5. Open the **Actions** tab and confirm the `Deploy static website to GitHub Pages` workflow completes successfully.
6. GitHub will show the published URL under **Settings → Pages**. It commonly follows `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

The included workflow uses GitHub's official Pages actions and deploys the repository root. No build step, Node.js, API key, or backend server is required.

## Functional features

- Responsive navigation with accessible mobile menu
- Section navigation and architecture links
- Search dialog that finds matching sections in the page
- Interactive AFTER HUMANITY chapter selector
- Hermes harness section covering design, agent loop, sandbox, and context engineering
- Explicit Hermes / WorldForge governance boundary and authorization-flow explanation
- Copy-to-clipboard project summary
- Responsive layout for desktop, tablet and mobile
- Keyboard focus styles and reduced-motion preference support

## Important implementation boundary

This is a functional **static website**, not the AH-AIOS backend. It does not yet implement accounts, database persistence, source uploads, real claims/evidence records, permission enforcement, Hermes execution, production audit logging, live observability, or AI API integrations. Architecture and workflow panels are illustrative proposals and are labelled accordingly. Replace any contact details or content placeholders before public launch.

## Apps of a Universe

- `apps.html` — the 12-app AFTER HUMANITY application directory
- `apps.css` — responsive app-directory and modal styling
- `apps.js` — app filters, app launchers, local prototype forms, and local record display

### Browser prototype apps

World Atlas, Identity Archive, Relationship Explorer, Source & Evidence Registry, Canon Governance, Visual Artifact Studio, AH-AIOS Workspace, and Creative Suite allow local record creation and viewing. Records use browser `localStorage` on the current device only. Mobile Suite, Desktop Apps, Offline Apps, and Reality Viewer display their current scope and limitations.

This is not a shared backend, secure multi-user environment, PDF ingestion service, real canon approval service, or Hermes execution engine. Do not enter sensitive data. App records are not uploaded or backed up.
