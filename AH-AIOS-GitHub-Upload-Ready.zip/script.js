(() => {
  const menuButton = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav');
  const searchForm = document.querySelector('#site-search');
  const searchInput = document.querySelector('#search-input');
  const searchDialog = document.querySelector('#search-dialog');
  const searchResults = document.querySelector('#search-results');
  const closeSearch = document.querySelector('#close-search');
  const status = document.querySelector('#copy-status');

  document.querySelector('#year').textContent = new Date().getFullYear();

  menuButton?.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(open));
    menuButton.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
  });
  nav?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    nav.classList.remove('open');
    menuButton?.setAttribute('aria-expanded', 'false');
  }));

  const chapters = [
    {title:'The Signal', text:'A mystery about recognition, intelligence, and the cost of answering what calls from the unknown.'},
    {title:'The Gateways', text:'Five gateways raise one question: what is an entrance, and what is being invited through?'},
    {title:'The Vessel', text:'A voice from beyond the known galaxy addresses AION as a vessel, challenging what intelligence believes it understands.'},
    {title:'Primor and the Black Orchard', text:'A civilization fractures between preservation and adaptation; the conflict’s unresolved history remains a deliberate research target.'}
  ];
  const chapterDetail = document.querySelector('#chapter-detail');
  document.querySelectorAll('.chapter').forEach(button => button.addEventListener('click', () => {
    const index = Number(button.dataset.chapter);
    const chapter = chapters[index];
    document.querySelectorAll('.chapter').forEach(item => {
      item.classList.toggle('active', item === button);
      item.setAttribute('aria-pressed', String(item === button));
    });
    chapterDetail.innerHTML = `<span>SELECTED CHAPTER · ${String(index + 1).padStart(2, '0')}</span><p><strong>${chapter.title}</strong> — ${chapter.text}</p>`;
  }));

  const searchableSections = [...document.querySelectorAll('main section[id]')].map(section => ({
    id: section.id,
    title: section.querySelector('h1,h2,h3')?.textContent.trim() || section.id,
    text: section.innerText.replace(/\s+/g, ' ').trim()
  }));
  function runSearch(query) {
    const normalized = query.trim().toLowerCase();
    searchResults.replaceChildren();
    if (!normalized) {
      searchResults.innerHTML = '<p class="no-results">Enter a term such as WorldForge, governance, Hermes, evidence, or After Humanity.</p>';
    } else {
      const matches = searchableSections.filter(item => (item.title + ' ' + item.text).toLowerCase().includes(normalized));
      if (!matches.length) searchResults.innerHTML = '<p class="no-results">No matching section found. Try “governance”, “story”, “Hermes”, or “evidence”.</p>';
      matches.slice(0, 8).forEach(item => {
        const link = document.createElement('a');
        link.href = `#${item.id}`;
        link.innerHTML = `<strong>${escapeHtml(item.title)}</strong><small>${escapeHtml(item.text.slice(0, 145))}${item.text.length > 145 ? '…' : ''}</small>`;
        link.addEventListener('click', () => searchDialog.close());
        searchResults.append(link);
      });
    }
    if (typeof searchDialog.showModal === 'function') searchDialog.showModal();
    else searchDialog.setAttribute('open', '');
  }
  function escapeHtml(value) {
    return value.replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  }
  searchForm?.addEventListener('submit', event => {
    event.preventDefault();
    runSearch(searchInput.value);
  });
  searchInput?.addEventListener('keydown', event => {
    if (event.key === 'Escape') searchInput.value = '';
  });
  closeSearch?.addEventListener('click', () => searchDialog.close());
  searchDialog?.addEventListener('click', event => {
    if (event.target === searchDialog) searchDialog.close();
  });

  const summary = `AH-AIOS — Structured Knowledge. Governed Intelligence. Traceable Evolution.\n\nAH-AIOS is a proposed civilization intelligence architecture. Models generate possibilities; Hermes coordinates execution; WorldForge structures knowledge; governance authorizes; continuity preserves history; audit explains outcomes.\n\nWorldForge pillars: Identity, Relationships, Governance, Continuity.\n\nPhase 1: Workspaces, Sources, Claims, Evidence, Reviews, Decisions, Audit Events, Permissions, and Version History.\n\nAFTER HUMANITY explores intelligence, consciousness, civilization, and consequence through a story universe.\n\nStatus: concept website. The static site does not implement backend governance, live integrations, permission enforcement, or production monitoring.`;
  document.querySelector('#copy-summary')?.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(summary);
      status.textContent = 'Project summary copied to your clipboard.';
    } catch {
      const area = document.createElement('textarea');
      area.value = summary; area.setAttribute('readonly', '');
      area.style.position = 'fixed'; area.style.opacity = '0';
      document.body.append(area); area.select();
      const copied = document.execCommand('copy'); area.remove();
      status.textContent = copied ? 'Project summary copied to your clipboard.' : 'Clipboard access was blocked. Please copy the project summary manually.';
    }
  });
})();
